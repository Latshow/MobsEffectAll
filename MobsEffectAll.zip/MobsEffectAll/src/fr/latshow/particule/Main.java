package fr.latshow.particule;

import org.bukkit.plugin.java.JavaPlugin;

import fr.latshow.particule.commands.Commandes;

public class Main extends JavaPlugin {
	
	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	

	
	@Override
	public void onEnable() {
		saveDefaultConfig();
		System.out.println(ANSI_YELLOW+"MobsEffectAll"+ANSI_GREEN+" loading"+ANSI_RESET);
		getServer().getPluginManager().registerEvents(new ParticuleListeners(this), this);
		getCommand("mea").setExecutor(new Commandes(this));
		
	}

	
	@Override
	public void onDisable() {
		System.out.println(ANSI_YELLOW+"MobsEffectAll"+ANSI_RED+" Disabling"+ANSI_RESET);
		
	}

}
