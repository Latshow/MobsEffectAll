package fr.latshow.particule;

import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class ParticuleListeners implements Listener {
	
	private Main main;
	
	public ParticuleListeners(Main main) {
		this.main = main;
	}
	
	public Entity mobsAll(EntityType mobs, String message, EntityDamageByEntityEvent event) {
		Entity entity = event.getEntity();
		Location entityloc = entity.getLocation();
		if(entity.getType() == mobs) {
			entity.getWorld().playEffect(entityloc, Effect.STEP_SOUND, Material.getMaterial(main.getConfig().getString(message)));
		}
		return entity;
	}
	
	
	
	@EventHandler
	public void onEffectSang(EntityDamageByEntityEvent event) {

		if(main.getConfig().getString("Mobs.Mobs_Effect") == "true") {
			mobsAll(EntityType.BAT, "Mobs.BAT.Particule", event);
			mobsAll(EntityType.BLAZE, "Mobs.BLAZE.Particule", event);
			mobsAll(EntityType.CAVE_SPIDER,"Mobs.CAVE_SPIDER.Particule", event);
			mobsAll(EntityType.CHICKEN, "Mobs.CHICKEN.Particule", event);
			mobsAll(EntityType.COW, "Mobs.COW.Particule", event);
			mobsAll(EntityType.CREEPER, "Mobs.CREEPER.Particule", event);//
			mobsAll(EntityType.DONKEY, "Mobs.DONKEY.Particule", event);
			mobsAll(EntityType.ELDER_GUARDIAN, "Mobs.ELDER_GUARDIAN.Particule", event);
			mobsAll(EntityType.ENDERMAN, "Mobs.ENDERMAN.Particule", event);
			mobsAll(EntityType.ENDERMITE, "Mobs.ENDERMITE.Particule", event);
			mobsAll(EntityType.EVOKER, "Mobs.EVOKER.Particule", event);
			mobsAll(EntityType.GHAST, "Mobs.GHAST.Particule", event);
			mobsAll(EntityType.GUARDIAN, "Mobs.GUARDIAN.Particule", event);
			mobsAll(EntityType.HORSE, "Mobs.HORSE.Particule", event);
			mobsAll(EntityType.HUSK, "Mobs.HUSK.Particule", event);
			mobsAll(EntityType.LLAMA, "Mobs.LLAMA.Particule", event);
			mobsAll(EntityType.MAGMA_CUBE, "Mobs.MAGMA_CUBE.Particule", event);
			mobsAll(EntityType.MUSHROOM_COW, "Mobs.MUSHROOM_COW.Particule", event);
			mobsAll(EntityType.MULE, "Mobs.MULE.Particule", event);
			mobsAll(EntityType.OCELOT, "Mobs.OCELOT.Particule", event);
			mobsAll(EntityType.PIG, "Mobs.PIG.Particule", event);
			mobsAll(EntityType.POLAR_BEAR, "Mobs.POLAR_BEAR.Particule", event);
			mobsAll(EntityType.RABBIT, "Mobs.RABBIT.Particule", event);
			mobsAll(EntityType.SHEEP, "Mobs.SHEEP.Particule", event);
			mobsAll(EntityType.SHULKER, "Mobs.SHULKER.Particule", event);
			mobsAll(EntityType.SILVERFISH, "Mobs.SILVERFISH.Particule", event);
			mobsAll(EntityType.SKELETON, "Mobs.SKELETON.Particule", event);
			mobsAll(EntityType.SKELETON_HORSE, "Mobs.SKELETON_HORSE.Particule", event);
			mobsAll(EntityType.SLIME, "Mobs.SLIME.Particule", event);
			mobsAll(EntityType.SPIDER, "Mobs.SPIDER.Particule", event);
			mobsAll(EntityType.SQUID, "Mobs.SQUID.Particule", event);
			mobsAll(EntityType.STRAY, "Mobs.STRAY.Particule", event);
			mobsAll(EntityType.VEX, "Mobs.VEX.Particule", event);
			mobsAll(EntityType.VILLAGER, "Mobs.VILLAGER.Particule", event);
			mobsAll(EntityType.VINDICATOR, "Mobs.VINDICATOR.Particule", event);
			mobsAll(EntityType.WITCH, "Mobs.WITCH.Particule", event);
			mobsAll(EntityType.WITHER_SKELETON, "Mobs.WITHER_SKELETON.Particule", event);
			mobsAll(EntityType.WOLF, "Mobs.WOLF.Particule", event);
			mobsAll(EntityType.ZOMBIE, "Mobs.ZOMBIE.Particule", event);
			mobsAll(EntityType.ZOMBIE_HORSE, "Mobs.ZOMBIE_HORSE.Particule", event);
			mobsAll(EntityType.PIG_ZOMBIE, "Mobs.PIG_ZOMBIE.Particule", event);
			mobsAll(EntityType.ZOMBIE_VILLAGER, "Mobs.ZOMBIE_VILLAGER.Particule", event);	
		}
		
		
	}

}
