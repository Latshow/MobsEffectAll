package fr.latshow.particule.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fr.latshow.particule.Main;

public class Commandes implements CommandExecutor {

	private Main main;
	public Commandes(Main main) {
		this.main = main;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] arg) {
		
		Player player = (Player) sender;
		if(cmd.getName().equalsIgnoreCase("mea")) {
			player.sendMessage("�2�l########################################");
			player.sendMessage("        �c�lPlugin version: �a0.1");
			player.sendMessage("    �6Give ideas to improve this plugin");
			player.sendMessage("�2�l########################################");
		}
		
		
		return false;
	}

}
